﻿Public Class jk
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Hide()
        pro.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Label1.Visible = False
        Label2.Visible = True
        Button1.Enabled = True
        Button2.Enabled = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Label2.Visible = False
        Label1.Visible = True
        Button2.Enabled = True
        Button1.Enabled = False
    End Sub
End Class