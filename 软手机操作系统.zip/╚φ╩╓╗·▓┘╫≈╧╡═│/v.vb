﻿Public Class v
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Hide()
        sta.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        CreateObject("Wscript.Shell").Run("D:\xbd.mp4")
    End Sub
End Class