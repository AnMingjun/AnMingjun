﻿Public Class lh
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a As String
        Dim b As String = "老头" & Str(Hour(Now)) + "时" + Str(Minute(Now)) + "分" + Str(Second(Now)) + "秒"
        a = TextBox1.Text
        Label1.Text = Label1.Text + vbCrLf + b + vbCrLf + a
        TextBox1.Text = ""
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Hide()
        dlqq.Show()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub lh_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class