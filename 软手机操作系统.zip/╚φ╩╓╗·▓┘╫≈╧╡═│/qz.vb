﻿Public Class qz
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Hide()
        qqset.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a As String = RichTextBox1.Text
        Dim b As String = "老头" & Str(Year(Now)) + "年" + Str(Month(Now)) + "月" + Str(DateAndTime.Day(Now)) + "日" + Str(Hour(Now)) + "时" + Str(Minute(Now)) + "分" + Str(Second(Now)) + "秒"
        RichTextBox2.Text = RichTextBox2.Text + vbCrLf + b + vbCrLf + a
        RichTextBox1.Text = ""
    End Sub
End Class