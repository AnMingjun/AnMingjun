﻿Public Class add
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Hide()
        pro.Show()
    End Sub





    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        If ProgressBar1.Value < 99 Then
            ProgressBar1.Visible = True
            Timer1.Enabled = True
        Else
            Hide()
            jk.Show()
        End If

    End Sub

    Private Sub Timer1_Tick_1(sender As Object, e As EventArgs) Handles Timer1.Tick
        If ProgressBar1.Value < 100 Then
            ProgressBar1.Value = ProgressBar1.Value + 1
        Else
            ProgressBar1.Visible = False
            Timer1.Enabled = False
            Hide()
            jk.Show()
        End If
    End Sub

    Private Sub ProgressBar1_Click(sender As Object, e As EventArgs) Handles ProgressBar1.Click

    End Sub



    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If ProgressBar2.Value < 100 Then
            ProgressBar2.Value = ProgressBar2.Value + 1
        Else
            ProgressBar2.Visible = False
            Timer2.Enabled = False
            CreateObject("Wscript.Shell").Run("D:\pinball\pinball.exe")
        End If
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        If ProgressBar2.Value < 99 Then
            ProgressBar2.Visible = True
            Timer2.Enabled = True
        Else
            CreateObject("Wscript.Shell").Run("D:\pinball\pinball.exe")
        End If
    End Sub

    Private Sub shandows(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class