﻿Public Class off
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        CreateObject("Wscript.Shell").Run("shutdown.exe -i")
        End
    End Sub

    Private Sub off_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class