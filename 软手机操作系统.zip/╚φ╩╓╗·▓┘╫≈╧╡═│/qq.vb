﻿Public Class qq


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Hide()
        pro.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Hide()
        dlqq.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Hide()
        dlqq.Show()
    End Sub

    Private Sub qq_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class