﻿Public Class pro
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Hide()
        sta.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        CreateObject("Wscript.Shell").Run("Calc.exe")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        CreateObject("Wscript.Shell").Run("C:\WINDOWS\system32\notepad.exe")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Hide()
        qq.Show()
    End Sub



    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Hide()
        add.Show()
    End Sub

    Private Sub pro_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click
        CreateObject("Wscript.Shell").Run("C:\WINDOWS\system32\mspaint.exe")
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        CreateObject("Wscript.Shell").Run("C:\Program Files\Windows NT\Accessories\wordpad.exe")
    End Sub

    Private Sub Button8_Click_1(sender As Object, e As EventArgs) Handles Button8.Click
        CreateObject("Wscript.Shell").Run("C:\WINDOWS\system32\msinfo32.exe")
    End Sub
    Private Sub Button11_Click_1(sender As Object, e As EventArgs) Handles Button11.Click
        CreateObject("Wscript.Shell").Run("C:\WINDOWS\system32\Taskmgr.exe")
    End Sub
    Private Sub Button10_Click_1(sender As Object, e As EventArgs) Handles Button10.Click
        CreateObject("Wscript.Shell").Run("C:\WINDOWS\system32\Magnify.exe")
    End Sub


End Class