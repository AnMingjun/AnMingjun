﻿Public Class dlqq
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Hide()
        pro.Show()
    End Sub

    Private Sub dlqq_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True And RadioButton2.Checked = False Then
            GroupBox1.Visible = True
            GroupBox2.Visible = False
        Else
            GroupBox1.Visible = False
            GroupBox2.Visible = True
        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton1.Checked = True And RadioButton2.Checked = False Then
            GroupBox1.Visible = True
            GroupBox2.Visible = False
        Else
            GroupBox1.Visible = False
            GroupBox2.Visible = True
        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        lh.Label1.Text = ""
        Hide()
        lh.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Hide()
        qqset.Show()
    End Sub



    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        lh.Label1.Text = ""
        Hide()
        lh.Show()
    End Sub



    Private Sub LinkLabel7_LinkClicked_1(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel7.LinkClicked
        lh.Label1.Text = ""
        Hide()
        lh.Show()
    End Sub

    Private Sub LinkLabel3_LinkClicked_1(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        lh.Label1.Text = ""
        Hide()
        lh.Show()
    End Sub

    Private Sub LinkLabel4_LinkClicked_1(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel4.LinkClicked
        lh.Label1.Text = ""
        Hide()
        lh.Show()
    End Sub

    Private Sub LinkLabel5_LinkClicked_1(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel5.LinkClicked
        lh.Label1.Text = ""
        Hide()
        lh.Show()
    End Sub

    Private Sub LinkLabel6_LinkClicked_1(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel6.LinkClicked
        lh.Label1.Text = ""
        Hide()
        lh.Show()
    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub
End Class